//
//  ViewControler2.h
//  Apr4
//
//  Created by Joe Gabela on 4/7/13.
//  Copyright (c) 2013 Joe Gabela. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>	//for CADisplayLink

@interface ViewController2: UIViewController {
	CADisplayLink *displayLink;
}

@end
