//
//  main.m
//  Apr4
//
//  Created by Joe Gabela on 4/6/13.
//  Copyright (c) 2013 Joe Gabela. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Apr4AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool
    {
        //Call the function NSLog.  Pass a string to it.
        NSLog(@"Arrived at the start of the main function.");

        return UIApplicationMain(argc, argv, nil, NSStringFromClass([Apr4AppDelegate class]));
    }
}
